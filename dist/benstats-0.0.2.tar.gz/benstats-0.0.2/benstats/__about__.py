# SPDX-FileCopyrightText: 2022-present gv-sh <gv-sh@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.2'
